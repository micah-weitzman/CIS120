(******************************************************************************)
(* PROBLEM 5: WRITING TEST CASES                                              *)
(******************************************************************************)

(* `SetTest` is a reuseable module that we'll use to test other modules that
   conform to the `SET` interface. When `SetTest` is instantiated with a
   particular set implementation, it will run all of its test cases against
   the set type defined in that implementation.  This means that the _same_
   tests can be used for both the OrderedListSet and BSTSet implementations --
   and that both implementations should behave the same for these tests!

   Read through the module, then write your test cases in the space provided
   below. Make sure NOT to test for structural equality with sets.  Instead,
   use the equals function specified in the interface.  Your TAs will be
   grading the completeness of your tests. *)

module SetTest (SetImpl: SetInterface.SET) = struct
  ;; open SetImpl

  (* We first redefine the `run_test` and `run_failing_test` functions so that
     they prepend the name of the set we're testing to the test description. *)

  let run_test desc = Assert.run_test (debug_name ^ ": " ^ desc)
  let run_failing_test desc = Assert.run_failing_test (debug_name ^ ": " ^ desc)

  ;; print_endline ("\n--- Running tests for " ^ debug_name ^ " ---")

  (* Here are a couple of test cases to help get you started... *)

  let test () : bool =
    is_empty empty
  ;; run_test "is_empty: call on empty returns true" test

  (* Note that some tests in this test module (such as the one below) may not
     pass until all the functions they depend on are implemented. For
     instance, the test below will fail for sets whose `set_of_list` function
     is not yet implemented (even if `is_empty` is correct).  This is fine:
     the goal here is just to record all the tests that we expect will pass
     when we get around to implementing everything later. *)

  let test () : bool =
    let s = set_of_list [1; 2; 3] in
    not (is_empty s)
  ;; run_test "is_empty: non-empty set returns false" test


(* Now, it's your turn! Make sure to comprehensively test all the other
   functions defined in the `SET` interface. It will probably be helpful to
   have the file `setInterface.ml` open as you work.  Your tests should stress
   the abstract properties of what it means to be a set, as well as the
   relationships among the operations provided by the SET interface.  Your
   tests should not assume that the underlying data structure was implemented
   in a certain way. For instance, your tests should not assume that the
   underlying implementation behind a set is a list/tree.  Additionally, if
   you are testing a function that relies on a helper/another function, first
   test the helper with a particular input to ensure that the helper works,
   then test the primary function with the same input used in the helper.

   We strongly advise that you write tests for the functions in the order they
   appear in the interface. Write tests for all of the functions here before
   you start implementing. After the tests are written, you should be able to
   implement the functions one at a time in the same order and see your tests
   incrementally pass.

   Your TAs will be manually grading the completeness of your test cases. *)

  (* ---------- Write your own test cases below. ---------- *)
  
(* is_empty  *)
let test () : bool = 
  is_empty empty 
;; run_test "is_empty: run on an empty list" test 

let test () : bool = 
  not( is_empty (set_of_list [1;2;3])) 
;; run_test "is_empty: run on a non empty list" test 


(* list_of_set *)
let test () : bool = 
  list_of_set (set_of_list[1;2;3]) = [1;2;3]
;; run_test "list_of_set: list length-3 in ascending order" test 

let test () : bool = 
  list_of_set (set_of_list [3;2;1]) = [1;2;3]
;; run_test "list_of_set: list length-3 in reverse order" test 

let test () : bool = 
  list_of_set (set_of_list [2;2;2]) = [2]
;; run_test "list_of_set: list length-3 duplicates" test 

let test () : bool = 
  list_of_set (set_of_list []) = []
;; run_test "list_of_set: empty list" test 


(* add *)
let test () : bool = 
  add 4 empty = set_of_list[4]
;; run_test "add: one value added to an empty list yields one value" test 

let test () : bool = 
  let s1 = set_of_list [1;2;3] in
  add 2 s1 = set_of_list [1;2;3]
;; run_test "add: adding a pre-elisting value doesn't change the set" test 

let test () : bool =
  let s1 = set_of_list [2;3;1] in 
  equals (add 4 s1) (set_of_list [1;2;3;4])
;; run_test "add: adding a value corerectly adds it to the set" test 



(* remove *)
let test () : bool =
  let s1 = set_of_list [1;2;3] in 
  remove 1 s1 = set_of_list [2;3]
;; run_test "remove: removes value from set" test 

let test () : bool = 
  let s1 = set_of_list [1;2;3] in 
  remove 4 s1 = s1
;; run_test "remove: returns the same list if elem. not already in set" test

let test () : bool = 
  remove 1 empty = empty
;; run_test "remove: remmoving from an empty set yields an empty set" test


(* member *)
let test () : bool = 
  not( member 1 empty )
;; run_test "member: calling func on empty set yields empty set" test 

let test () : bool = 
  member 2 (set_of_list [1;2;3])
;; run_test "member: correct use of the function" test 

let test () : bool = 
 not(member 4 (set_of_list [1;2;3]))
;; run_test "member: calling number that doesn't exists in valid set" test 


(* size *)
let test () : bool = 
  size (set_of_list [1;2;3]) = 3
;; run_test "size: size returns correct value of 3 in length-3 set" test 

let test () : bool = 
  size empty = 0
;; run_test "size: empty list returns zero" test 

let test () : bool = 
  size (set_of_list [2;2;2]) = 1
;; run_test "size: corerectly counts values only once" test 


(* equals *)
let test () : bool =
  let s1 = set_of_list [1;2;3] in
  let s2 = set_of_list [2;3;1] in 
  equals s1 s2 
;; run_test "equals: order doesn't matter" test 

let test () : bool = 
  let s1 = set_of_list [1;2;3] in
  let s2 = set_of_list [4;2;3;1] in 
  not(equals s1 s2)
;; run_test "equals: list have to be the same size" test 

let test () : bool = 
  equals empty empty
;; run_test "equals: empty lists are equal" test

let test () : bool = 
  let s1 = set_of_list [2;2;2] in 
  let s2 = set_of_list [2] in 
  equals s1 s2 
;; run_test "equals: the same element doesn't appear twice" test 


(* set_of_list *)
let test () : bool = 
  let s1 = add 4 empty in
  equals (set_of_list [4]) s1
;; run_test "set_of_list: list of 4 is the same as 4 added to empty set" test

let test () : bool = 
  let s1 = add 1 empty in 
  let s2 = add 2 s1 in 
  let s3 = add 3 s2 in 
  equals (set_of_list [3;1;2]) s3
;; run_test "set_of_list: works with length 3 list" test

let test () : bool = 
  let s1 = add 1 empty in 
  let s2 = add 2 s1 in 
  let s3 = add 3 s2 in 
  equals (set_of_list [1;2;2;2;3;3;3;3;3;1]) s3
;; run_test "set_of_list: properly adds only one of each value" test 


  (* ---------- Write your own test cases above. ---------- *)

end

(* We now instantiate the tests so they are executed for both OrderedListSet
   and BSTSet.  Don't modify anything below this comment. *)

module TestOrderedListSet = SetTest(ListSet.OrderedListSet)
;; print_newline ()

module TestBSTSet = SetTest(TreeSet.BSTSet)
;; print_newline ()
