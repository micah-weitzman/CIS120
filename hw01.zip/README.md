### CIS 120 Homework 1: Finger Exercises

Please open the file ``intro.ml`` and begin there.  Additional about getting started can be found in the

- [Homework Description](http://www.cis.upenn.edu/~cis120/current/hw/hw01)

Once you are finished, use the "Zip" menu item to create a file called
"submit-hw01(<time>).zip" and upload it here:

- [Homework Submission Site](https://fling.seas.upenn.edu/~cis120/current/admin/dashboard.html)

Codio documentation can be found here:

- [CIS 120 Codio Documentation](http://www.cis.upenn.edu/~cis120/current/codio.shtml)
